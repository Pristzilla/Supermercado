package es.unican.ps.supermercado.daoLayer;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import es.unican.ps.supermercado.entities.Articulo;

@Stateless
public class ArticulosDAO implements IArticulosDAOLocal, IArticulosDAORemote {

	@PersistenceContext(unitName="supermercadoPU")
	private EntityManager em;

	@Override
	public Articulo crearArticulo(Articulo a) {
		try  {
			em.persist(a);
			return a;
		} catch (EntityExistsException e) {
			return null;
		}
	}

	@Override
	public Articulo modificarArticulo(Articulo a) {
		em.merge(a);
		return a;
	}

	@Override
	public Articulo eliminarArticulo(Articulo a) {
		Articulo art = em.find(Articulo.class, a.getId());
		if (art == null) {
			return null;
		}
		em.remove(art);
		return art;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Articulo> buscarArticuloPorNombre(String nombre) {
		Query q = em.createQuery("SELECT a FROM Articulo a WHERE a.nombre LIKE ':%nombre%'");
		q.setParameter("nombre", nombre);
		return (List<Articulo>) q.getResultList();
	}

	@Override
	public Articulo buscarArticuloPorId(Long id) {
		return em.find(Articulo.class, id);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Articulo> articulos() {
		Query q = em.createQuery("SELECT a FROM Articulo a");
		return (List<Articulo>) q.getResultList();
	}

}
