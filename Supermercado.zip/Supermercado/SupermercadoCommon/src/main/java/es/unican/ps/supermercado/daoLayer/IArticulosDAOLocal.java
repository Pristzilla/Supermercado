package es.unican.ps.supermercado.daoLayer;

import javax.ejb.Local;

@Local
public interface IArticulosDAOLocal extends IArticulosDAO {

}
