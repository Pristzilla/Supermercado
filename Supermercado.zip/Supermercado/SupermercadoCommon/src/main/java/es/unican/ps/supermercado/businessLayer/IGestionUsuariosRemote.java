package es.unican.ps.supermercado.businessLayer;

import javax.ejb.Remote;

@Remote
public interface IGestionUsuariosRemote extends IGestionUsuarios {

}
