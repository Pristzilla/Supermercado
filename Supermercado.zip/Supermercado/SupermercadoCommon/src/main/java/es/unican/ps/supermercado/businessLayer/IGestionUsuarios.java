package es.unican.ps.supermercado.businessLayer;

import es.unican.ps.supermercado.entities.Usuario;

public interface IGestionUsuarios {

	public Usuario registraUsuario(Usuario u);
	
}
