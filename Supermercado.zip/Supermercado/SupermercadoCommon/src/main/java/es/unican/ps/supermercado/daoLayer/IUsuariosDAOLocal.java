
package es.unican.ps.supermercado.daoLayer;

import javax.ejb.Local;

@Local
public interface IUsuariosDAOLocal extends IUsuariosDAO {

}
