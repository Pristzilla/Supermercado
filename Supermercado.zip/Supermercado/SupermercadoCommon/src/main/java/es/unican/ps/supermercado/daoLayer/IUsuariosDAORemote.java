package es.unican.ps.supermercado.daoLayer;

import javax.ejb.Remote;

@Remote
public interface IUsuariosDAORemote extends IUsuariosDAO {

}
