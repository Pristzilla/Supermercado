package es.unican.ps.supermercado.businessLayer;

import javax.ejb.Local;

@Local
public interface IProcesaPedidosLocal extends IProcesaPedidos {

}
