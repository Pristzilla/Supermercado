package es.unican.ps.supermercado.daoLayer;

import javax.ejb.Local;

@Local

public interface IPedidosDAOLocal extends IPedidosDAO {

}
