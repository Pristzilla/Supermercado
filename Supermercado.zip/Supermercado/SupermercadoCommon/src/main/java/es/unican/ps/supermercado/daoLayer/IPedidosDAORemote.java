package es.unican.ps.supermercado.daoLayer;

import javax.ejb.Remote;

@Remote

public interface IPedidosDAORemote extends IPedidosDAO {

}
